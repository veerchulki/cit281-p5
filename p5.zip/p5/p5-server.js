""// p5-server.js

const express = require('express');
const { gameState, updateGame, resetGame } = require('./p5-game');
const app = express();
const PORT = 4000;

app.use(express.json());
app.use(express.static('public'));

// GET: Retrieve game state
app.get('/api/game-state', (req, res) => {
    res.json({
        player: gameState.player,
        enemies: gameState.enemies,
        score: gameState.score,
        isGameOver: gameState.isGameOver
    });
});

// POST: Update game state (triggered by client actions)
app.post('/api/update-game', (req, res) => {
    updateGame();
    res.json({ message: 'Game updated', gameState });
});

// POST: Reset game state
app.post('/api/reset-game', (req, res) => {
    resetGame();
    res.json({ message: 'Game reset', gameState });
});

// Server Listener
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
""