""// p5-class.js

// PlayerShip Class
class PlayerShip {
    constructor(x, y, speed) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.bullets = [];
    }

    move(direction) {
        if (direction === "left") {
            this.x -= this.speed;
        } else if (direction === "right") {
            this.x += this.speed;
        }
    }

    fire() {
        const bullet = new Bullet(this.x + 15, this.y, -5);
        this.bullets.push(bullet);
    }

    updateBullets() {
        this.bullets.forEach(bullet => bullet.move());
        this.bullets = this.bullets.filter(bullet => bullet.y > 0);
    }
}

// EnemyShip Class
class EnemyShip {
    constructor(x, y, speed) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.isAlive = true;
    }

    move() {
        this.y += this.speed;
    }

    destroy() {
        this.isAlive = false;
    }
}

// Bullet Class
class Bullet {
    constructor(x, y, velocity) {
        this.x = x;
        this.y = y;
        this.velocity = velocity;
    }

    move() {
        this.y += this.velocity;
    }
}

module.exports = { PlayerShip, EnemyShip, Bullet };
""
