// Get elements
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startButton = document.getElementById('startButton');
const resetButton = document.getElementById('resetButton');
const scoreDisplay = document.getElementById('score');

// Set up canvas dimensions
canvas.width = 800;
canvas.height = 600;

// Game state
let gameState = {
    player: new PlayerShip(canvas.width / 2, canvas.height - 50),
    enemies: [],
    bullets: [],
    score: 0,
    gameOver: false
};

// Handle keypresses for player movement and shooting
let keys = {
    left: false,
    right: false,
    fire: false
};

// Listen for key events
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') keys.left = true;
    if (e.key === 'ArrowRight') keys.right = true;
    if (e.key === ' ') keys.fire = true;
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'ArrowLeft') keys.left = false;
    if (e.key === 'ArrowRight') keys.right = false;
    if (e.key === ' ') keys.fire = false;
});

// Create the enemies and add them to the game state
function spawnEnemies() {
    let rows = 5;
    let cols = 10;
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            let x = 80 + col * 60;
            let y = 50 + row * 50;
            gameState.enemies.push(new EnemyShip(x, y));
        }
    }
}

// Update the game state (move ships, bullets, check for collisions)
function updateGame() {
    // Move player
    if (keys.left && gameState.player.x > 0) gameState.player.x -= gameState.player.speed;
    if (keys.right && gameState.player.x < canvas.width - gameState.player.width) gameState.player.x += gameState.player.speed;

    // Move bullets
    gameState.bullets.forEach(bullet => bullet.move());
    gameState.bullets = gameState.bullets.filter(bullet => bullet.y > 0); // Remove bullets out of bounds

    // Move enemies
    gameState.enemies.forEach(enemy => enemy.move());

    // Check for collisions between bullets and enemies
    gameState.bullets.forEach(bullet => {
        gameState.enemies.forEach(enemy => {
            if (bullet.collidesWith(enemy)) {
                enemy.isDestroyed = true;
                bullet.isDestroyed = true;
                gameState.score += 10; // Increase score
            }
        });
    });

    // Remove destroyed enemies and bullets
    gameState.enemies = gameState.enemies.filter(enemy => !enemy.isDestroyed);
    gameState.bullets = gameState.bullets.filter(bullet => !bullet.isDestroyed);

    // Check if all enemies are destroyed (win condition)
    if (gameState.enemies.length === 0) {
        gameState.gameOver = true;
        alert('You win!');
    }

    // Check if any enemy reaches the player (lose condition)
    gameState.enemies.forEach(enemy => {
        if (enemy.y + enemy.height >= gameState.player.y) {
            gameState.gameOver = true;
            alert('Game Over!');
        }
    });
}

// Draw everything (player, enemies, bullets)
function drawGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw player
    gameState.player.draw(ctx);

    // Draw enemies
    gameState.enemies.forEach(enemy => enemy.draw(ctx));

    // Draw bullets
    gameState.bullets.forEach(bullet => bullet.draw(ctx));

    // Draw score
    scoreDisplay.textContent = `Score: ${gameState.score}`;
}

// Game loop (update and draw every 60ms)
function gameLoop() {
    if (!gameState.gameOver) {
        updateGame();
        drawGame();
        requestAnimationFrame(gameLoop);
    }
}

// Start the game
startButton.addEventListener('click', () => {
    gameState = {
        player: new PlayerShip(canvas.width / 2, canvas.height - 50),
        enemies: [],
        bullets: [],
        score: 0,
        gameOver: false
    };
    spawnEnemies();
    gameLoop();
});

// Reset the game
resetButton.addEventListener('click', () => {
    gameState = {
        player: new PlayerShip(canvas.width / 2, canvas.height - 50),
        enemies: [],
        bullets: [],
        score: 0,
        gameOver: false
    };
    spawnEnemies();
    gameLoop();
});

// Fire bullet
function fireBullet() {
    if (!gameState.gameOver) {
        let bullet = new Bullet(gameState.player.x + gameState.player.width / 2, gameState.player.y);
        gameState.bullets.push(bullet);
    }
}

// Listen for spacebar to fire
document.addEventListener('keydown', (e) => {
    if (e.key === ' ') fireBullet();
});

// Initial game setup
spawnEnemies();
