""// p5-game.js

const { PlayerShip, EnemyShip, Bullet } = require('./p5-class');

// Game State
const gameState = {
    player: new PlayerShip(250, 450, 5),
    enemies: [],
    bullets: [],
    score: 0,
    isGameOver: false
};

// Spawn Enemies
const spawnEnemies = () => {
    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 3; j++) {
            gameState.enemies.push(new EnemyShip(100 + i * 60, 50 + j * 50, 1));
        }
    }
};

// Update Game State
const updateGame = () => {
    if (gameState.isGameOver) return;

    // Move player's bullets
    gameState.player.updateBullets();
    
    // Move enemies
    gameState.enemies.forEach(enemy => enemy.move());

    // Collision Detection
    gameState.player.bullets.forEach(bullet => {
        gameState.enemies.forEach((enemy, index) => {
            if (
                bullet.x > enemy.x &&
                bullet.x < enemy.x + 40 &&
                bullet.y > enemy.y &&
                bullet.y < enemy.y + 40 &&
                enemy.isAlive
            ) {
                enemy.destroy();
                gameState.enemies.splice(index, 1);
                gameState.score += 100;
            }
        });
    });

    // Check for Game Over
    if (gameState.enemies.some(enemy => enemy.y >= 450)) {
        gameState.isGameOver = true;
    }
};

// Reset Game
const resetGame = () => {
    gameState.player = new PlayerShip(250, 450, 5);
    gameState.enemies = [];
    gameState.bullets = [];
    gameState.score = 0;
    gameState.isGameOver = false;
    spawnEnemies();
};

// Initialize
spawnEnemies();

// Export Functions
module.exports = {
    gameState,
    updateGame,
    resetGame
};
""
